#bower compatible socket.io client
versions will be compatitble as main repo of socket.io-client
#installation
`bower install sio-client`